const express = require("express");
require("../src/db/conn.js");
const  Skill = require("../src/models/course");
const router = require("../src/routers/skill");


const app = express();
const port = process.env.PORT || 3000;
app.get("/skills/", (request, response) => {
    response.status(200).send("skill");
})

app.use(express.json());
app.use(router);


app.listen(port, () => {
    console.log(`connection is live at port no.${port}`);
})