const express = require("express");
const router = new express.Router();

const Skill = require("../models/course");

router.post("/course",async(req, res) => {
    try{
      const addingSkillRecords = new Skill(req.body)
      console.log(req.body);

      const insertSkill = await addingSkillRecords .save();
      res.status(201).send(insertSkill);

    }catch(e){
        res.status(400).send(e);

    }
    
})
//we will handel get request
router.get("/course",async(req, res) => {
    try{
        const getSkill = await Skill.find({});
      res.send(getSkill);

    }catch(e){
        res.send(e);

    }
})
//we will handel get of delete
router.delete("/course/:id",async(req, res) => {
    try{
        const _id = req.params.id;
        const getSkill = await Skill.findByIdAndDelete({_id});
      res.send(getSkill);

    }catch(e){
        res.send(e);

    }
})
module.exports = router;
